<?php $this->load->view('/inc/requests_header.php'); ?>
<div class="container" style="width:100%; max-width:1000px; margin:20px auto;">
  

  <!-- Search + New -->
  <div style="display:flex; gap:10px; align-items:center; margin-bottom:15px;">
    <h3  style="margin-bottom:10px; color: #101C89;">Requests</h3>
    <a class="btn  rounded-pill" href="<?= site_url('requests/create'); ?>" style="margin-left:auto; background:#101C89; color: white; width: 130px;">New Request</a>
  </div>

 <div class="table-resposive">
    
     <table id="applications_table" class="table table-striped table-bordered  " style="width:100%">
        <thead>
          <tr style="background:#101C89; color:#fff;">
            <th style="padding:10px;">#</th>
            <th style="padding:10px;">Invoice No</th>
            <th style="padding:10px;">Date</th>
            <th style="padding:10px;">Customer</th>
            <th style="padding:10px; text-align:right;">Total</th>
            <th style="padding:10px;">Status</th>
            <th style="padding:10px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($rows)): foreach ($rows as $r): ?>
            <tr>
              <td style="padding:8px;"><?= (int)$r['id']; ?></td>
              <td style="padding:8px;"><?= html_escape($r['invoice_no']); ?></td>
              <td style="padding:8px;"><?= date('Y-m-d', strtotime($r['invoice_date'])); ?></td>
              <td style="padding:8px;"><?= html_escape($r['customer_name']); ?></td>
              <td style="padding:8px; text-align:right;">
                <?= html_escape($r['currency'] ?? 'USD'); ?> <?= number_format((float)($r['total'] ?? $r['subtotal'] ?? 0), 2); ?>
              </td>
              <td style="padding:8px; color: 
  <?= $r['status'] == 'Cancelled' ? 'red' : ($r['status'] == 'Paid' ? 'green' : 'black'); ?>">
  <?= html_escape($r['status']); ?>
</td>

              <td style="padding:8px;">
                <a style="background:#101C89; width: 100px; color: white;" class="btn rounded-pill" style="min-width:70px; display:inline-block; text-align:center;"
                   href="<?= site_url('requests/view/'.$r['id']); ?>">View</a>

                

                <!-- Cancel: use a hidden POST form to change status -->
                <form method="post" action="<?= site_url('requests/cancel/'.$r['id']); ?>" style="display:inline;" onsubmit="return confirm('Cancel this request?');">
                  <?php if (isset($this->security)) : ?>
                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                           value="<?= $this->security->get_csrf_hash(); ?>">
                  <?php endif; ?>
                  <!--<button type="submit" class="btn btn-dark rounded-pill" style="min-width:70px;">Cancel</button>-->
                </form>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr>
              <td colspan="7" style="padding:12px; text-align:center;">No requests found.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>


  <!-- Simple pager (optional) -->
  <?php if (($pages ?? 1) > 1): ?>
    <div style="margin-top:10px; display:flex; gap:6px; flex-wrap:wrap;">
      <?php for ($p=1;$p<=$pages;$p++): ?>
        <a class="btn btn-dark rounded-pill" href="<?= site_url('requests').'?page='.$p.($search?('&q='.urlencode($search)):''); ?>"
           style="<?= $p == $page ? 'background:#333;' : '' ?>"><?= $p; ?></a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>
<script>
    //*********** Data tables 
   $(document).ready(function(){
   var table = $('#applications_table').DataTable({
  
      "order": [],
        "scrollX": true,
       order: [0, 'asc'],
   
   
   mark: true,
         dom: 'Bfrtip',
        lengthMenu: [
             [ 10, 25, 50, 100, -1],
             ['10 rows', '25 rows', '50 rows', '100 rows', 'Show All']
         ],
   
   
   
   
   
         buttons: [
             'pageLength',
             {
                 extend: 'copyHtml5',
                 exportOptions: {
                     columns: ':visible'
                 }
             },
             {
                 extend: 'excelHtml5',
                 exportOptions: {
                     columns: ':visible'
                 }
             },
             {
                 extend: 'csvHtml5',
                 exportOptions: {
                     columns: ':visible'
                 }
             },
             
             {
                 extend: 'pdfHtml5',
                // download: 'open',
                 exportOptions: {
                     columns: ':visible'
                 }
   
             },
             {
                 extend: 'print',
                 exportOptions: {
                     columns: ':visible'
                 }
             },
             'colvis'
         ],
         columDefs: [{
             targets: -1,
             visible: false
         }]
   
   
   }); //End DT
   
   });  //end of document ready 
 </script>
   