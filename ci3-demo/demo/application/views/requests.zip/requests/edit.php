
<?php $this->load->view('/inc/requests_header.php'); ?>
<!-- create_request.php -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Create Invoice</title>
  <style>

    /* Show everything normally, but when printing, hide the actions bar */
@media print {
  .actions { display: none !important; }
  
  /* optional: keep colors close to screen colors */
  body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}

    @page { size: A4; margin: 20mm 13mm; }
     .invoice-page body {
      font-family: Arial, sans-serif;
      font-size: 13px;
      color: #111;
      background: #fff;
      margin: 0; padding: 0;
    }
    .wrap { max-width: 890px; margin: 20px auto; }

    .invoice-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #101C89;
      padding: 40px 50px;
     
    }

    .invoice-logo img { height: 70px; }

    .invoice-meta {
      color: white;
      text-align: right;
    }

    .invoice-meta div {
      line-height: 1.5;
    }

    .grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-top: 18px;
    }

    .panel {
      border: 1px solid #002060;
      padding: 12px 16px;
      border: 2px solid black;
    }

    .panel label {
      font-weight: bold;
      display: block;
      margin-bottom: 4px;
    }

    .panel input,
    .panel select {
      width: 100%;
      padding: 6px;
     
      font-size: 13px;
      margin-bottom: 10px;
       outline: none;


    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      border: 2px solid black;
    }

    th, td {
      border: 1px solid #002060;
      padding: 10px;
      vertical-align: top;
    }

    th {
       background: #101C89;
      color: white;
      text-align: left;
      font-weight: bold;
      height: 25px;
    }

    td input,
td textarea {
  width: 100%;
  box-sizing: border-box;
  padding: 6px 8px;
  font: inherit;
  border: none;
  outline: none;
  resize: none;

}
    .right {  }

    .actions-row {
      display: flex;
      justify-content: space-between;
      margin-top: 10px;
      font-size: 13px;
      font-weight: bold;
    }

    .add-line {
      color: #002060;
      cursor: pointer;
    }

    .delete-btn {
      color: red;
      font-weight: bold;
      cursor: pointer;
    }

    .signature-total {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      gap: 16px;
    }

    .signature-box {
      flex: 1;
      border: 2px solid #002060;
      padding: 12px;
    }

    .signature-box .label {
      font-weight: bold;
      font-size: 14px;
      margin-bottom: 10px;
    }

    .signature-line {
      margin-top: 35px;
      border-top: 2px solid #002060;
      width: 70%;
    }

    .totals-box {
      flex: 1;
      border: 1px solid #002060;
    }

    .totals-box table {
      margin: 0;
    }

    .totals-box th {
       background: #101C89;
      color: white;
      padding-left: 12px;
    }

    .totals-box td {
      text-align: right;
      padding-right: 12px;
    }

    .notes {
      margin-top: 24px;
      border-top: 1px dotted #444;
      padding-top: 12px;
      font-size: 15px;
      line-height: 1.6;
      font-weight: 650;
      border: 2px solid black;
      padding-left: 12px;
    }

    .highlight-red { color: red; }
    .highlight-purple { color: purple; }
    .highlight-green { color: green; font-weight: bold; }
    .highlight-blue { color: blue; font-weight: bold; }

    .thanks {
      margin-top: 24px;
      text-align: center;
      text-transform: uppercase;
      font-weight: bold;
      color: #002060;
    }

    .actions {
      text-align: right;
      margin-top: 20px;
    }

    .btn {
       background: #101C89;
      color: white;
      padding: 8px 14px;
      border: none;
      cursor: pointer;

    }
    td textarea {
  height: 100%;
  line-height: 1.5;
}

.company-info {
  display: grid;
  gap: 10px;

}
.company-info input{
  border: none !important;
}
.info-row {
  display: grid;
  grid-template-columns: 60px 1fr;
  align-items: center;
  gap: 10px;

}

.info-row label {
  font-weight: bold;
  text-align: left; /* change from right to left */
  padding-left: 0;  /* remove any spacing */
  font-weight:700;
  font-size: 15px !important;

}


.info-row input {
  width: 100%;
  padding: 6px 8px;
  font-size: 14px;
  border: 1px solid #ccc;
  margin-top: 6px !important;
}
td{
  font-weight: bold;
  align-items: center !important;
}

  </style>
</head>
<body>

  <div class="invoice-page">

<div class="wrap">
 
<form id="requestForm" method="post" action="<?= site_url('requests/create/store'); ?>">
<?php if (isset($this->security)) : ?>
  <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
         value="<?= $this->security->get_csrf_hash(); ?>">
<?php endif; ?>

 <div class="actions">
    <button style="width:120px;margin-bottom:10px;" type="submit"
            class="btn btn-dark rounded-pill" name="__action" value="update">Update</button>

    <button style="width:120px;margin-bottom:10px;" type="submit"
            class="btn btn-dark rounded-pill" name="__action" value="cancel">Cancel</button>
  </div>

<input type="hidden" name="phase_text" id="phase_text" value="">
<input type="hidden" name="notes" id="notes" value="">

<input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" 
       value="<?= $this->security->get_csrf_hash(); ?>">
    <!-- HEADER -->
    <div class="invoice-header">
      <div class="invoice-logo">
        <img src="<?= base_url('assets/images/hodman.png'); ?>" alt="Company Logo">
      </div>
      <div class="invoice-meta">
        <h2 style="font-weight: 700; margin-top: -10px; margin-bottom: 15px;">INVOICE</h2>

        <div id="invoice_number_display">#INV/2025/843</div>
        <div>Date: <input type="date" id="invoice_date" name="invoice_date" value="<?= isset($today)?html_escape($today):date('Y-m-d'); ?>" style="background:none;border:none;color:white;"></div>
      </div>
    </div>


    <!-- SELLER & CUSTOMER INFO -->
    <div class="grid-2">
      <div class="panel company-info">
  <div class="info-row">
    <label   for="seller_name">Seller:</label>
    <input type="text" id="seller_name" name="seller_name" value="Hodman Construction Company">
  </div>
  <div class="info-row">
    <label for="seller_address">Address:</label>
    <input type="text" id="seller_address" name="seller_address" value="Barsame Business center, Hargeisa">
  </div>
  <div class="info-row">
    <label for="seller_email">Mail:</label>
    <input type="email" id="seller_email" name="seller_email" value="Hodmanconstructioncompany@gmail.com">
  </div>
  <div class="info-row">
    <label for="seller_phone">Phone:</label>
    <input type="text" id="seller_phone" name="seller_phone" value="0634041807">
  </div>
</div>


 <div class="panel" style="padding: 26px;">
  <label style="margin-top: -12px;">Customer:</label>

  <!-- Select: pre-select the saved customer -->
  <select style="padding: 10px;" name="customer_id" id="customer_id_edit" onchange="fillCustomerEdit(this)">
    <option value="">— Select Customer —</option>
    <?php if (!empty($customers)): foreach ($customers as $c): ?>
      <option
        value="<?= (int)$c['customer_id']; ?>"
        data-name="<?= html_escape($c['customer_name']); ?>"
        data-address="<?= html_escape($c['address']); ?>"
        data-phone="<?= html_escape($c['phone']); ?>"
        <?= ((int)$header['customer_id'] === (int)$c['customer_id']) ? 'selected' : ''; ?>>
        <?= html_escape($c['customer_name']); ?>
      </option>
    <?php endforeach; endif; ?>
  </select>

  <!-- Saved snapshot fields (you can still hand-edit them if needed) -->
  <input style="padding: 10px;" type="text"
         name="customer_name" id="cust_name"
         value="<?= html_escape($header['customer_name']); ?>"
         placeholder="Name">

  <input style="padding: 10px;" type="text"
         name="customer_address" id="cust_addr"
         value="<?= html_escape($header['customer_address']); ?>"
         placeholder="Address">

  <input style="padding: 10px;" type="text"
         name="customer_phone" id="cust_phone"
         value="<?= html_escape($header['customer_phone']); ?>"
         placeholder="Phone">
</div>

<script>
function fillCustomerEdit(sel){
  var opt = sel.options[sel.selectedIndex];
  if (!opt) return;
  var name = opt.getAttribute('data-name') || '';
  var addr = opt.getAttribute('data-address') || '';
  var phone= opt.getAttribute('data-phone') || '';
  document.getElementById('cust_name').value  = name;
  document.getElementById('cust_addr').value  = addr;
  document.getElementById('cust_phone').value = phone;
}
</script>


    </div>

    <!-- ITEMS TABLE -->
    <table>
      <thead>
        <tr>
          <th style="width:60px;">Code</th>
          <th>Description</th>
          <th style="width:70px;" class="right">Qty</th>
          <th style="width:100px;" class="right">U.price</th>
          <th style="width:110px;" class="right">Amount</th>
          <th style="width:40px;">Action</th> 
        </tr>
      </thead>
     <tbody id="items">
  <?php if (!empty($items)): foreach ($items as $k => $it): ?>
    <tr>
      <!-- Code -->
      <td>
        <input type="text" name="item_code[]"
               value="<?= html_escape($it['code'] !== '' ? $it['code'] : ($k+1)); ?>">
      </td>

      <!-- Description -->
      <td>
        <textarea name="item_description[]" rows="3" required><?= html_escape($it['description']); ?></textarea>
      </td>

      <!-- Qty -->
      <td class="right">
        <input class="calc qty" type="text" name="item_qty[]"
               value="<?= number_format((float)$it['qty'], 2, '.', ''); ?>">
      </td>

      <!-- Unit price -->
      <td class="right">
        <input class="calc price" type="text" name="item_unit_price[]"
               value="<?= number_format((float)$it['unit_price'], 2, '.', ''); ?>">
      </td>

      <!-- Amount (auto, still posted if you want) -->
      <td class="right">
        <input class="amount" type="text" name="item_amount[]" readonly
               value="<?= number_format((float)$it['amount'], 2, '.', ''); ?>">
      </td>

      <!-- Action (allow removing in edit) -->
      <td class="right">
        <span class="delete-btn" onclick="deleteRow(this)">✖</span>
      </td>

      <!-- UOM (hidden if you don’t show it) -->
      <input type="hidden" name="item_uom[]" value="<?= html_escape($it['uom'] ?? 'unit'); ?>">
    </tr>
  <?php endforeach; else: ?>
    <!-- If no items, render one empty editable row -->
    <tr>
      <td><input type="text" name="item_code[]" value="1"></td>
      <td><textarea name="item_description[]" rows="3" required></textarea></td>
      <td class="right"><input class="calc qty" type="text" name="item_qty[]" value="1.00"></td>
      <td class="right"><input class="calc price" type="text" name="item_unit_price[]" value="0.00"></td>
      <td class="right"><input class="amount" type="text" name="item_amount[]" readonly value="0.00"></td>
      <td class="right"><span class="delete-btn" onclick="deleteRow(this)">✖</span></td>
      <input type="hidden" name="item_uom[]" value="unit">
    </tr>
  <?php endif; ?>
</tbody>


    </table>

    <div class="actions-row">
      <div class="add-line" onclick="addLine()">+ Add Line</div>
    </div>  
 
    <!-- SIGNATURE + TOTALS -->
    <div class="signature-total">
      <div class="signature-box">
        <div class="label">Signature:</div>
        <div class="signature-line"></div>
      </div>
   <div class="totals-box">
  <table>
    <tr>
      <th>Total:</th>
      <td>
        <span id="total_show">
          <?= html_escape($header['currency'] ?? 'USD'); ?>
          <?= number_format((float)($header['subtotal'] ?? $header['total'] ?? 0), 2); ?>
        </span>
      </td>
    </tr>
    <tr>
      <th>G.Total:</th>
      <td>
        <span id="gtotal_show">
          <?= html_escape($header['currency'] ?? 'USD'); ?>
          <?= number_format((float)($header['total'] ?? $header['subtotal'] ?? 0), 2); ?>
        </span>
      </td>
    </tr>
  </table>
</div>

    </div>

    <!-- NOTES -->
<div class="notes" id="notes_section">
  <h4>Notes:</h4>

  <p>
    Please find attached Invoice No.
    <span class="highlight-red" id="note_invoice">
      <?= html_escape($header['invoice_no']); ?>
    </span>,
    <span class="highlight-purple" id="note_date">
      <?= date('F d, Y', strtotime($header['invoice_date'])); ?>
    </span>,
    issued by <span class="highlight-purple">Hodman Construction Company</span>.
  </p>

  <p>
  The total amount of
  <span class="highlight-green" id="note_amount_display">
    <?= html_escape($header['currency'] ?? 'USD'); ?>
    <?= number_format((float)($header['total'] ?? 0), 2); ?>
  </span>
  corresponds to the third phase of your project.
</p>

  <p>
  <strong>Deposit to account:</strong>
  <span class="highlight-green" id="bank_account_display">
    <?= html_escape($header['bank_account'] ?? ''); ?>
  </span>
</p>

  <p>
  <strong>Payment due in</strong>
  <span class="highlight-blue" id="due_days_display">
    <?= html_escape($header['due_days'] ?? ''); ?>
  </span>
  <strong>days.</strong>
</p>

  <p>Contact Admin & Finance for questions.</p>
  <p>Customer: ____________________________</p>
</div>


    <!-- THANKS + BUTTON -->
    <div class="thanks">THANK YOU FOR YOUR CONTINUED TRUST AND COOPERATION</div>
   
  </form>
</div>
</div>

<!-- JS -->
<script>

// Helper: get clean innerText
function _txt(el){ return (el && el.innerText ? el.innerText : '').replace(/\s+/g,' ').trim(); }

// Build plain-text Notes from your current UI
function composeNotes(){
  const invDisp = document.getElementById('invoice_number_display');
  const invNum  = _txt(invDisp);
  const dtTxt   = _txt(document.getElementById('note_date'));       // already set in your code
  const amtTxt  = _txt(document.getElementById('note_amount'));      // already updated by recalc()
  const bank    = (document.getElementById('bank_account')?.value || '').trim();
  const due     = (document.getElementById('due_days')?.value || '').trim();

  return [
    `Please find attached Invoice No. ${invNum}, ${dtTxt}, issued by Hodman Construction Company.`,
    `The total amount of ${amtTxt} corresponds to the third phase of your project.`,
    `Deposit to account: ${bank}`,
    `Payment due in ${due} days.`,
    `Contact Admin & Finance for questions.`
  ].join('\n');
}

// If you want a default phase text (adjust as needed)
function composePhase(){
  return 'The third phase of the project'; // or any text you want to store
}

// Keep note invoice number (red span) synced with the display header
(function syncNoteInvoiceOnLoad(){
  const invDisp = document.getElementById('invoice_number_display');
  const noteInv = document.getElementById('note_invoice');
  if (invDisp && noteInv) noteInv.innerText = _txt(invDisp);
})();

// On submit: fill hidden fields, ensure at least one description exists if you didn’t use "required"
(function hookSubmit(){
  // ✔️ ku xir kaliya form-ka Create/Edit
  const form = document.getElementById('requestForm');
  if (!form) return; // boggan ma aha create/edit → iska bax

  // (ikhtiyaari) xaqiiji in action-ku yahay create/store ama edit/{id}/update
  const action = form.getAttribute('action') || '';
  const isCreateOrEdit = /\/requests\/(create\/store|edit\/\d+\/update)/.test(action);
  if (!isCreateOrEdit) return;

  form.addEventListener('submit', function(e){
    // Hubi in ugu yaraan hal description jiro
    const descs = Array.from(document.querySelectorAll('textarea[name="item_description[]"]'))
      .map(t => t.value.trim()).filter(Boolean);

    if (descs.length === 0) {
      e.preventDefault();
      alert('Please enter at least one line description.');
      return false;
    }

    // Buuxi hidden fields haddii aad isticmaalayso
    const phase = document.getElementById('phase_text');
    const notes = document.getElementById('notes');
    if (phase) phase.value = composePhase();
    if (notes) notes.value = composeNotes();
  });
})();
</script>

<script>
function fillCustomer(sel) {
  const opt = sel.options[sel.selectedIndex];
  document.getElementById('cust_name').value = opt.getAttribute('data-name') || '';
  document.getElementById('cust_addr').value = opt.getAttribute('data-address') || '';
  document.getElementById('cust_phone').value = opt.getAttribute('data-phone') || '';
}

function recalc() {
  let total = 0;
  const rows = document.querySelectorAll('#items tr');
  rows.forEach(row => {
    const qty = parseFloat(row.querySelector('.qty')?.value || 0);
    const price = parseFloat(row.querySelector('.price')?.value || 0);
    const amt = qty * price;
    row.querySelector('.amount').value = amt.toFixed(2);
    total += amt;
  });
  document.getElementById('total_show').innerText = 'USD ' + total.toFixed(2);
  document.getElementById('gtotal_show').innerText = 'USD ' + total.toFixed(2);
  document.getElementById('note_amount').innerText = 'USD ' + total.toFixed(2);
}

function addLine() {
  const tbody = document.getElementById('items');
  const rowCount = tbody.querySelectorAll('tr').length;
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input type="text" name="item_code[]" value="${rowCount + 1}" readonly></td>
    <td><textarea name="item_description[]" rows="3" required></textarea></td>
    <td class="right"><input class="calc qty" type="text" name="item_qty[]" value="1.00"></td>
    <td class="right"><input class="calc price" type="text" name="item_unit_price[]" value="0.00"></td>
    <td class="right"><input class="amount" type="text" name="item_amount[]" readonly value="0.00"></td>
    <td class="right"><span class="delete-btn" onclick="deleteRow(this)">✖</span></td>
    <input type="hidden" name="item_uom[]" value="unit">
  `;
  tbody.appendChild(tr);
}

function deleteRow(el) {
  const row = el.closest('tr');
  row.remove();
  recalc();
}

document.addEventListener('input', e => {
  if (e.target.classList.contains('calc')) recalc();
});

document.getElementById('invoice_date').addEventListener('change', function () {
  const d = new Date(this.value);
  const formatted = d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  document.getElementById('note_date').innerText = formatted;
});

recalc();
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  // Find the "Print" button inside your actions bar
  var actions = document.querySelector('.actions');
  if (!actions) return;

  // Find the first button that has the text "Print"
  var btns = Array.from(actions.querySelectorAll('button'));
  var printBtn = btns.find(b => (b.textContent || '').trim().toLowerCase() === 'print');
  if (!printBtn) return;

  // Prevent form submission and open the print dialog
  printBtn.addEventListener('click', function (e) {
    e.preventDefault();       // stop POST
    window.print();           // open print dialog
  });
});
</script>
<script>
function recalc() {
  var total = 0;
  document.querySelectorAll('#items tr').forEach(function(row){
    var q = parseFloat((row.querySelector('.qty')   && row.querySelector('.qty').value)   || 0);
    var p = parseFloat((row.querySelector('.price') && row.querySelector('.price').value) || 0);
    var amt = (q * p) || 0;
    var amtInput = row.querySelector('.amount');
    if (amtInput) amtInput.value = amt.toFixed(2);
    total += amt;
  });
  var currency = '<?= addslashes($header['currency'] ?? 'USD'); ?>';
  var t = currency + ' ' + total.toFixed(2);
  var el1 = document.getElementById('total_show');
  var el2 = document.getElementById('gtotal_show');
  if (el1) el1.textContent = t;
  if (el2) el2.textContent = t;
}

function deleteRow(el){
  var tr = el.closest('tr');
  if (tr) tr.remove();
  recalc();
}

document.addEventListener('input', function(e){
  if (e.target.classList.contains('calc')) recalc();
});

// Optional: add-line handler you already have can remain the same,
// just make sure it creates inputs with classes: qty, price, amount.
recalc();
</script>

<script>
(function () {
  var currency = '<?= addslashes($header['currency'] ?? 'USD'); ?>';

  function recalcTotalsAndNotes() {
    // 1) Recompute total from table rows
    var total = 0;
    document.querySelectorAll('#items tr').forEach(function(row){
      var q = parseFloat((row.querySelector('.qty')   && row.querySelector('.qty').value)   || 0) || 0;
      var p = parseFloat((row.querySelector('.price') && row.querySelector('.price').value) || 0) || 0;
      var amt = q * p;
      var aEl = row.querySelector('.amount');
      if (aEl) aEl.value = amt.toFixed(2);
      total += amt;
    });

    // 2) Update the totals panel
    var t = currency + ' ' + total.toFixed(2);
    var totalShow = document.getElementById('total_show');
    var gtotalShow = document.getElementById('gtotal_show');
    if (totalShow) totalShow.textContent = t;
    if (gtotalShow) gtotalShow.textContent = t;

    // 3) Update the Notes amount
    var noteAmt = document.getElementById('note_amount_display');
    if (noteAmt) noteAmt.textContent = t;
  }

  // Hook quantity/unit price changes
  document.addEventListener('input', function (e) {
    if (e.target.classList && (e.target.classList.contains('qty') || e.target.classList.contains('price'))) {
      recalcTotalsAndNotes();
    }
  });

  // Reflect bank account input in the span
  var bankInput = document.getElementById('bank_account');
  var bankSpan  = document.getElementById('bank_account_display');
  if (bankInput && bankSpan) {
    bankInput.addEventListener('input', function(){ bankSpan.textContent = bankInput.value.trim(); });
  }

  // Reflect due days input in the span
  var dueInput = document.getElementById('due_days');
  var dueSpan  = document.getElementById('due_days_display');
  if (dueInput && dueSpan) {
    dueInput.addEventListener('input', function(){ dueSpan.textContent = dueInput.value.trim(); });
  }

  // Initial sync on page load
  recalcTotalsAndNotes();
  if (bankInput && bankSpan) bankSpan.textContent = bankInput.value.trim();
  if (dueInput && dueSpan)   dueSpan.textContent  = dueInput.value.trim();
})();
</script>


</body>
</html>


