<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Hygiene Report</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

  <style>
    body{ font-family: 'Segoe UI', sans-serif; margin: 24px; }
    .filters{ display:flex; flex-wrap:wrap; gap:.75rem; align-items:flex-end; margin-bottom:12px; }
    .filters .form-group{ display:flex; flex-direction:column; }
    @media (max-width: 576px){ .filters{ gap:.5rem } }
    table.dataTable thead th{ background:#f33; color:#fff; }
  </style>
</head>
<body>

<h2>Hygiene Report</h2>

<!-- Flash -->
<?php foreach (['success','danger','error','warning','info'] as $k): if ($msg = $this->session->tempdata($k)): ?>
<div class="alert alert-<?= ($k==='danger' || $k==='error')?'danger':$k; ?>"><?= $msg; ?></div>
<?php $this->session->unset_tempdata($k); endif; endforeach; ?>

<!-- Filters -->
<?= form_open('hygiene/report-hygiene/results', ['id' => 'reportForm']); ?>
  <?= csrf_field(); ?>
  <div class="filters">
    <div class="form-group">
      <label>Class</label>
      <select name="class_id">
        <option value="0" <?= (int)$class_id===0?'selected':''; ?>>All classes</option>
        <?php foreach ($classes as $c): ?>
          <option value="<?= (int)$c['id']; ?>" <?= ((int)$class_id===(int)$c['id'])?'selected':''; ?>>
            <?= html_escape($c['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-group">
      <label>From</label>
      <input type="date" name="from_date" value="<?= html_escape($from_date); ?>" required>
    </div>

    <div class="form-group">
      <label>To</label>
      <input type="date" name="to_date" value="<?= html_escape($to_date); ?>" required>
    </div>

    <div class="form-group">
      <button type="submit">Filter</button>
    </div>
  </div>
</form>

<div class="table-wrap">
  <table id="hygieneReport" class="display nowrap" style="width:100%">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Class</th>
        <th>Normal</th>
        <th>Nails</th>
        <th>Hair</th>
        <th>Both</th>
        <th>Marked days</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach (($rows ?? []) as $r):
        $marked = (int)$r['total_nr'] + (int)$r['total_nl'] + (int)$r['total_hr'] + (int)$r['total_bh'];
      ?>
        <tr>
          <td><?= (int)$r['student_id']; ?></td>
          <td><?= html_escape($r['full_name']); ?></td>
          <td><?= html_escape($r['class_name']); ?></td>
          <td><?= (int)$r['total_nr']; ?></td>
          <td><?= (int)$r['total_nl']; ?></td>
          <td><?= (int)$r['total_hr']; ?></td>
          <td><?= (int)$r['total_bh']; ?></td>
          <td><?= $marked; ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script>
$(function(){
  $('#hygieneReport').DataTable({
    scrollX: true,
    pageLength: 100,
    dom: 'Blfrtip',
    buttons: ['pageLength','copy','excel','csv','pdf','print','colvis'],
    order: [[2,'asc'],[0,'asc']]
  });
});
</script>
</body>
</html>
